import React from 'react'

function Header() {
  return (
    <>
    <div className='bg-info p-4 text-center fs-2 container-fluid'>Emploiee imformation</div>
    </>
  )
}

export default Header